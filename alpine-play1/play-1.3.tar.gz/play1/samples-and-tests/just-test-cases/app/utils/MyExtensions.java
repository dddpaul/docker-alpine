package utils;

import java.util.*;

public class MyExtensions extends play.templates.JavaExtensions {

	public static String up(String s) {
		return s.toUpperCase();
	}
    
}

