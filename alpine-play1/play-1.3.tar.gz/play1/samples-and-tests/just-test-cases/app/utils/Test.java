package utils;

public class Test {
    
    public String yop() {
        return "Yop";
    }
    
}