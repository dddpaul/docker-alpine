package controllers;

import models.*;
import play.*;
import play.mvc.*;
import java.util.*;

public class Projects extends CRUD {

    
    
}

