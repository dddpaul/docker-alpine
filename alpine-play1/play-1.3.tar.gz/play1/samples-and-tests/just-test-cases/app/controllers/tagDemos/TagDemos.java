package controllers.tagDemos;

import play.mvc.Controller;

public class TagDemos extends Controller {

    public static void yesNo() {
        render();
    }

    public static void i18n() {
        render();
    }

}
