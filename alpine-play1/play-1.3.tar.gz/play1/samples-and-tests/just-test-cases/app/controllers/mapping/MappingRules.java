package controllers.mapping;

import play.*;
import play.mvc.*;

import java.util.*;

import models.*;

public class MappingRules extends Controller {

    public static void index() {
        render();
    }
    
}

