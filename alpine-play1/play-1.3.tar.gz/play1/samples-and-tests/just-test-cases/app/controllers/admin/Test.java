package controllers.admin;

import models.*;
import controllers.*;
import play.*;
import play.mvc.*;
import java.util.*;

public class Test extends Controller {

    public static void index() {
    }

}

