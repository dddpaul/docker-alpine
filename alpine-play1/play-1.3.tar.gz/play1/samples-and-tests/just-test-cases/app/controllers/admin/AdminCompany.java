package controllers.admin;

import models.*;
import controllers.*;
import play.*;
import play.mvc.*;
import java.util.*;

@CRUD.For(Company.class)
public class AdminCompany extends CRUD {

}

