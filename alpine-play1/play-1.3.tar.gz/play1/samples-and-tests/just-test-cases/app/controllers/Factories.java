package controllers;

import play.*;
import play.mvc.*;

import java.util.*;

import models.*;

@CRUD.For(Factory.class)
public class Factories extends CRUD {}

