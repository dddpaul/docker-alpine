package controllers.sample;

import play.mvc.*;

public class Photo extends Controller {
    
    public static void index() {
        renderText("Ok");
    }
    
}