package mapping;

import java.util.*;

public class MappingRule {

    public static String kiki() {
        return "KIKI";
    }
    
}

