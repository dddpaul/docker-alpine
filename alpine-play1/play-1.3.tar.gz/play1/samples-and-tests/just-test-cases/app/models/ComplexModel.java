package models;

public class ComplexModel {

	public String name;
	public String surname;
	public String phone;
	
}
