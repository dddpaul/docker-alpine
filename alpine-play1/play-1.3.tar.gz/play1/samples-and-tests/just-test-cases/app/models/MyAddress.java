package models;

import java.util.*;

import play.data.validation.*;

public class MyAddress {

    @Required
    public String street;
    public int number;
    
}

