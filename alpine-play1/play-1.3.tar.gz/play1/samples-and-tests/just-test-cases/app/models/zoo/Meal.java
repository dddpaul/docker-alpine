package models.zoo;

import javax.persistence.Entity;

import play.db.jpa.Model;

@Entity
public class Meal extends Model {

}
