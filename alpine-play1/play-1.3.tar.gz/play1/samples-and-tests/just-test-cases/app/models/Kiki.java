package models;

import java.util.*;

public class Kiki {

	public static String yip() {
		return "xxxx";
	}
    
}

